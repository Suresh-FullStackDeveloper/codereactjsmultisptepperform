import React, { Component } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndPaymentDetails extends Component {
  //   shouldComponentUpdate (nextProps) {
  //     if (
  //       this.props.emiratesid !== nextProps.isEmiratesId ||
  //       this.props.level !== nextProps.level
  //     ) {
  //       return true
  //     } else {
  //       return false
  //     }
  //   }
  back = e => {
    e.preventDefault()
    this.props.prevStep()
  }

  continue = e => {
    e.preventDefault()
    //const isEmiratesId = this.props.validateEmiratesId()
    // const isPassport = this.props.validatePassport()
    // if (isEmiratesId && isPassport) {
    this.props.nextStep()
    //  }
  }

  render () {
    const { profession } = this.props

    const {
      //  profession,
      cashorcheque,
      sourceoffunds,
      purposeoftransaction,
      beneficiaryname,
      bankaccountdetails,
      expectedannualactivity,
      annualvalue,
      numberoftransactions,

      // email,
      // phone,
      handleChange,
      //   validateFirstName,
      //   validateLastName,
      //   isErrorFirstName,
      //   isErrorLastName,
      //   errorMessageFirstName,
      //   errorMessageLastName
      validateprofession,
      isErrorProfession,
      isErrorbeneficiaryname,
      errorMessagebeneficiaryname,
      isErrorexpectedannualactivity,
      errorMessageexpectedannualactivity,

      errorMessageProfession,
      validateCashorcheque,
      validateSourceofFunds
    } = this.props

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { label: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={2}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='profession' className='form-group__label'>
                Profession
              </label>
              <input
                type='text'
                //value={profession}
                defaultValue={profession}
                name='profession'
                // onChange={'profession'}
                onBlur={validateprofession}
                id='profession'
                value={this.props.profession}
                onChange={this.props.onChange}
                className='form-control'
              />
              <p className='error'>
                {isErrorProfession && errorMessageProfession}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='cash or cheque' className='form-group__label'>
                Cash or Cheque
              </label>
              <input
                type='text'
                value={cashorcheque}
                name='middle name'
                onChange={'cashorcheque'}
                onBlur={validateCashorcheque}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='source of funds' className='form-group__label'>
                Source of Funds
              </label>
              <input
                type='text'
                value={sourceoffunds}
                name='sourceoffunds'
                onChange={'sourceoffunds'}
                onBlur={validateSourceofFunds}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='purposeoftransaction'
                className='form-group__label'
              >
                Purpose of Transaction
              </label>
              <input
                type='text'
                value={purposeoftransaction}
                name='purpose of transaction'
                onChange={'purposeoftransaction'}
                onBlur={purposeoftransaction}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='beneficiaryname' className='form-group__label'>
                Beneficiary Name
              </label>
              <input
                type='text'
                value={beneficiaryname}
                name='beneficiaryname'
                onChange={'beneficiaryname'}
                onBlur={beneficiaryname}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorbeneficiaryname && errorMessagebeneficiaryname}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='bankaccountdetails' className='form-group__label'>
                Bank Account Details
              </label>
              <input
                type='text'
                value={bankaccountdetails}
                name='bankaccountdetails'
                onChange={'bankaccountdetails'}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='expectedannualactivity'
                className='form-group__label'
              >
                Expected Annual Activity
              </label>
              <input
                type='text'
                value={expectedannualactivity}
                name='expectedannualactivity'
                onChange={'expectedannualactivity'}
                onBlur={expectedannualactivity}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorexpectedannualactivity &&
                  errorMessageexpectedannualactivity}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='annualvalue' className='form-group__label'>
                Annual Value
              </label>
              <input
                type='text'
                value={annualvalue}
                name='annualvalue'
                onChange={'annualvalue'}
                onBlur={annualvalue}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='numberoftransactions
'
                className='form-group__label'
              >
                Number of Transactions
              </label>
              <input
                type='text'
                value={numberoftransactions}
                name='numberoftransactions'
                onChange={'numberoftransactions'}
                onBlur={numberoftransactions}
                className='form-group__input'
              />
            </div>
          </div>

          <div style={{ textAlign: 'center' }}>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default IndPaymentDetails
