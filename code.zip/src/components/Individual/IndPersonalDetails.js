import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndPersonalDetails extends Component {
  continue = e => {
    e.preventDefault()
    // const isFirstNameValid = this.props.validateFirstName()
    //   const isLastNameValid = this.props.validateLastName()
    // if (isFirstNameValid && isLastNameValid) {
    //   this.props.nextStep()
    // }
    this.props.nextStep()
  }
  // IndPersonalDetails = () => {
  //   /*  Initial State */
  //   let [firstname, setname] = useState('')

  //   /* The handleChange() function to set a new state for input */
  //   const handleChange = event => {
  //     setname(event.target.value)
  //   }
  // }

  render () {
    const { firstname } = this.props

    const {
      //firstname,
      middlename,
      lastname,
      residentialstatus,
      area,
      district,
      city,
      emiratesorstate,
      province,
      country,
      temporaryaddress,
      permanentaddress,
      completepermanentaddress,
      nationality,
      dateofbirth,
      coutnryofbirth,
      mobilenumber,

      // email,
      // phone,
      handleChange,
      validateFirstName,
      validateLastName,
      isErrorFirstName,
      isErrorLastName,
      errorMessageFirstName,
      errorMessageLastName,
      validateMiddleName,
      isErrorMiddleName,
      errorMessageMiddleName,
      ResidentialStatus,
      isErrorResidentialStatus,
      errorMessageResidentialStatus,
      Area,
      isErrorArea,
      errorMessageArea,
      // City,
      // isErrorcity,
      // errorMessagecity,
      // isErroremiratesorstate,
      // errorMessageemiratesorstate,
      // isErrorprovince,
      // errorMessageemiratesorprovince,
      // isErrorcountry,
      // errorMessageemiratesorcountry,
      // isErrortemporaryaddress,
      // errorMessagetemporaryaddress,
      // isErrorpermanentaddress,
      // errorMessagepermanentaddress,
      // isErrorcompletepermanentaddress,
      // errorMessagecompletepermanentaddress,
      // isErrornationality,
      // errorMessagenationality,
      isErrordateofbirth,
      errorMessagedateofbirth,
      isErrorcoutnryofbirth,
      errorMessagecoutnryofbirth
    } = this.props

    return (
      // <div className='form'>
      <form>
        <Stepper
          steps={[
            { label: 'Personal details' },
            { label: 'Address details' },
            { label: 'Payment Details' },
            { label: 'Summary' }
          ]}
          activeStep={0}
          styleConfig={{
            activeBgColor: '#2b7cff',
            activeTextColor: '#fff',
            inactiveBgColor: '#fff',
            inactiveTextColor: '#2b7cff',
            completedBgColor: '#fff',
            completedTextColor: '#2b7cff',
            size: '3em'
          }}
          className={'stepper'}
          stepClassName={'stepper__step'}
        />

        <div className='form-group'>
          <div className='form-group__element'>
            <label htmlFor='first name' className='form-group__label'>
              First name
            </label>
            <input
              type='text'
              //value={firstname}
              //onChange={this.props.handleChange('firstName')}
              //value={'firstname'}
              name='first name'
              // onChange={'firstname'}
              onBlur={validateFirstName}
              defaultValue={firstname}
              id='firstname'
              value={this.props.email}
              onChange={this.props.onChange}
              className='form-control'
            />
            <p className='error'>{isErrorFirstName && errorMessageFirstName}</p>
          </div>
          <div className='form-group__element'>
            <label htmlFor='middle name' className='form-group__label'>
              Middle name
            </label>
            <input
              type='text'
              value={middlename}
              name='middle name'
              onChange={'middlename'}
              onBlur={validateMiddleName}
              className='form-group__input'
            />
            <p className='error'>
              {isErrorMiddleName && errorMessageMiddleName}
            </p>
          </div>
          <div className='form-group__element'>
            <label htmlFor='last name' className='form-group__label'>
              Last name
            </label>
            <input
              type='text'
              //value={lastname}
              name='last name'
              onChange={'lastname'}
              onBlur={validateLastName}
              className='form-group__input'
            />
            <p className='error'>{isErrorLastName && errorMessageLastName}</p>
          </div>
          <div className='form-group__element'>
            <label htmlFor='residentialstatus' className='form-group__label'>
              Residential Status
            </label>
            <input
              type='text'
              value={residentialstatus}
              name='residential status'
              onChange={'residentialstatus'}
              onBlur={ResidentialStatus}
              className='form-group__input'
            />
            <p className='error'>
              {isErrorResidentialStatus && errorMessageResidentialStatus}
            </p>
          </div>
          <div className='form-group__element'>
            <label htmlFor='area' className='form-group__label'>
              Area
            </label>
            <input
              type='text'
              value={area}
              name='area'
              onChange={'area'}
              onBlur={Area}
              className='form-group__input'
            />
          </div>
          <div className='form-group__element'>
            <label htmlFor='district' className='form-group__label'>
              District
            </label>
            <input
              type='district'
              value={district}
              name='email'
              onChange={'district'}
              className='form-group__input'
            />
          </div>
          <div className='form-group__element'>
            <label htmlFor='city' className='form-group__label'>
              City
            </label>
            <input
              type='text'
              value={city}
              name='city'
              onChange={'city'}
              // onBlur={City}
              className='form-group__input'
            />
          </div>
          <div className='form-group__element'>
            <label htmlFor='emiratesorstate' className='form-group__label'>
              Emirates or State
            </label>
            <input
              type='text'
              value={emiratesorstate}
              name='emiratesorstate'
              onChange={'emiratesorstate'}
              onBlur={emiratesorstate}
              className='form-group__input'
            />
          </div>
          <div className='form-group__element'>
            <label htmlFor='province' className='form-group__label'>
              Province
            </label>
            <input
              type='text'
              value={province}
              name='province'
              onChange={'province'}
              onBlur={province}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrorprovince && errorMessageemiratesorprovince}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='country' className='form-group__label'>
              Country
            </label>
            <input
              type='text'
              value={country}
              name='country'
              onChange={'country'}
              onBlur={country}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrorcountry && errorMessageemiratesorcountry}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='temporaryaddress' className='form-group__label'>
              Temporary Address
            </label>
            <input
              type='text'
              value={temporaryaddress}
              name='temporaryaddress'
              onChange={'temporaryaddress'}
              onBlur={temporaryaddress}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrortemporaryaddress && errorMessagetemporaryaddress}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='permanentaddress' className='form-group__label'>
              Permanent Address
            </label>
            <input
              type='text'
              value={permanentaddress}
              name='permanentaddress'
              onChange={'permanentaddress'}
              onBlur={permanentaddress}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrorpermanentaddress && errorMessagepermanentaddress}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label
              htmlFor='completepermanentaddress'
              className='form-group__label'
            >
              Complete Permanent Address
            </label>
            <input
              type='text'
              value={completepermanentaddress}
              name='completepermanentaddress'
              onChange={'completepermanentaddress'}
              onBlur={completepermanentaddress}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrorcompletepermanentaddress &&
                  errorMessagecompletepermanentaddress}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='nationality' className='form-group__label'>
              Nationality
            </label>
            <input
              type='text'
              value={nationality}
              name='nationality'
              onChange={'nationality'}
              onBlur={nationality}
              className='form-group__input'
            />
            {/* <p className='error'>
                {isErrornationality && errorMessagenationality}
              </p> */}
          </div>
          <div className='form-group__element'>
            <label htmlFor='dateofbirth' className='form-group__label'>
              Date of Birth
            </label>
            <input
              type='text'
              value={dateofbirth}
              name='dateofbirth'
              onChange={'dateofbirth'}
              onBlur={dateofbirth}
              className='form-group__input'
            />
            <p className='error'>
              {isErrordateofbirth && errorMessagedateofbirth}
            </p>
          </div>

          <div className='form-group__element'>
            <label htmlFor='coutnryofbirth' className='form-group__label'>
              Country of Birth
            </label>
            <input
              type='text'
              value={coutnryofbirth}
              name='coutnryofbirth'
              onChange={'coutnryofbirth'}
              onBlur={coutnryofbirth}
              className='form-group__input'
            />
            <p className='error'>
              {isErrorcoutnryofbirth && errorMessagecoutnryofbirth}
            </p>
          </div>
          <div className='form-group__element'>
            <label htmlFor='mobilenumber' className='form-group__label'>
              Mobile Number
            </label>
            <input
              type='text'
              value={mobilenumber}
              name='mobilenumber'
              onChange={'mobilenumber'}
              className='form-group__input'
            />
          </div>
        </div>

        <div style={{ textAlign: 'center' }}>
          <button
            className='buttons__button buttons__button--next'
            onClick={this.continue}
          >
            Next
          </button>
        </div>
      </form>
      // </div>
    )
  }
}

export default IndPersonalDetails
