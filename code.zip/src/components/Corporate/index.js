import React, { Component } from 'react'

// import PersonalDetails from './PersonalDetails'
// import CourseDetails from './CourseDetails'
// import Summary from './Summary'

import CorpPersonalDetails from './CorpPersonalDetails'
import CorpAddressDetails from './CorpAddressDetails'
import CorpPaymentDetails from './CorpPaymentDetails'
import CorpSummary from './CorpSummary'
import CorpTradelicenseDetails from './CorpTradelicenseDetails'
//Sample data

//const levelsData = ['Beginner', 'Intermediate', 'Advanced']

class Corporate extends Component {
  state = {
    step: 1,
    firstname: '',
    lastname: '',
    email: '',
    phone: '',
    courses: [],
    level: '',
    isErrorFirstName: true,
    isErrorLastName: true,
    errorMessageFirstName: '',
    errorMessageLastName: ''
  }

  nextStep = () => {
    const { step } = this.state
    this.setState({
      step: step + 1
    })
  }

  prevStep = () => {
    const { step } = this.state
    this.setState({
      step: step - 1
    })
  }

  handleChange = input => e => {
    this.setState({
      [input]: e.target.value
    })

    if (input === 'firstname') {
      if (this.state.firstname.length >= 1) {
        this.setState({
          isErrorFirstName: false
        })
      }
    } else if (input === 'lastname') {
      if (this.state.lastname.length >= 1) {
        this.setState({
          isErrorLastName: false
        })
      }
    }
  }

  validateFirstName = () => {
    if (this.state.firstname.length < 2) {
      this.setState({
        isErrorFirstName: true,
        errorMessageFirstName: 'Type your first name (at least 2 characters)'
      })
      return false
    }
    return true
  }

  validateLastName = () => {
    if (this.state.lastname.length < 2) {
      this.setState({
        isErrorLastName: true,
        errorMessageLastName: 'Type your last name (at least 2 characters)'
      })
      return false
    }
    return true
  }

  submitData = e => {
    e.preventDefault()
    alert('Data sent')
  }

  render () {
    const {
      step,
      firstname,
      lastname,
      email,
      phone,
      city,
      handleChange,
      validateFirstName,
      validateLastName,
      validateMiddleName,
      isErrorMiddleName,
      errorMessageMiddleName,
      residentialstatus,
      isErrorResidentialStatus,
      errorMessageResidentialStatus,
      Area,
      isErrorArea,
      errorMessageArea,
      // City,
      isErrorcity,
      errorMessagecity,
      isErroremiratesorstate,
      errorMessageemiratesorstate,
      isErrorprovince,
      errorMessageemiratesorprovince,
      isErrorcountry,
      errorMessageemiratesorcountry,
      isErrortemporaryaddress,
      errorMessagetemporaryaddress,
      isErrorpermanentaddress,
      errorMessagepermanentaddress,
      isErrorcompletepermanentaddress,
      errorMessagecompletepermanentaddress,
      isErrornationality,
      errorMessagenationality,
      isErrordateofbirth,
      errorMessagedateofbirth,
      isErrorcoutnryofbirth,
      errorMessagecoutnryofbirth,
      // courses,

      level,
      isErrorFirstName,
      isErrorLastName,
      errorMessageFirstName,
      errorMessageLastName
    } = this.state

    // nextStep = () => {
    //   const { step } = this.state
    //   this.setState({
    //     step: step + 1
    //   })
    // }

    // prevStep = () => {
    //   const { step } = this.state
    //   this.setState({
    //     step: step - 1
    //   })
    // }

    // handleChange = input => e => {
    //   this.setState({
    //     [input]: e.target.value
    //   })
    // }
    // const coursesOptions = coursesData.map(el => ({
    //   course: el.courseName,
    //   id: el.id,
    //   category: el.category
    // }))

    // const coursesChosen = coursesData.filter(el => courses.includes(el.id))
    // const coursesChosenSummary = coursesChosen.map(el => (
    //   <p key={el.id}>
    //     {el.courseName} - {el.category}
    //   </p>
    // ))

    // const chosenLevel = level

    // const levelOptions = levelsData.map((el, index) => (
    //   <option key={index} value={el}>
    //     {el}
    //   </option>
    // ))

    switch (step) {
      case 1:
        return (
          <CorpPersonalDetails
            nextStep={this.nextStep}
            handleChange={this.handleChange}
            firstname={firstname}
            middlename={this.middlename}
            lastname={lastname}
            residentialstatus={this.residentialstatus}
            area={this.area}
            district={this.district}
            city={city}
            emiratesorstate={this.emiratesorstate}
            province={this.province}
            country={this.country}
            temporaryaddress={this.temporaryaddress}
            permanentaddress={this.permanentaddress}
            completepermanentaddress={this.completepermanentaddress}
            nationality={this.nationality}
            dateofbirth={this.dateofbirth}
            coutnryofbirth={this.coutnryofbirth}
            mobilenumber={this.mobilenumber}
            // email,
            // phone,
            handleChange={handleChange}
            validateFirstName={validateFirstName}
            validateLastName={validateLastName}
            isErrorFirstName={isErrorFirstName}
            isErrorLastName={isErrorLastName}
            errorMessageFirstName={errorMessageFirstName}
            errorMessageLastName={errorMessageLastName}
            validateMiddleName={validateMiddleName}
            isErrorMiddleName={isErrorMiddleName}
            errorMessageMiddleName={errorMessageMiddleName}
            residentialstatus={residentialstatus}
            isErrorResidentialStatus={isErrorResidentialStatus}
            errorMessageResidentialStatus={errorMessageResidentialStatus}
            Area={Area}
            isErrorArea={isErrorArea}
            errorMessageArea={errorMessageArea}
            //City={City}
            isErrorcity={isErrorcity}
            errorMessagecity={errorMessagecity}
            isErroremiratesorstate={isErroremiratesorstate}
            errorMessageemiratesorstate={errorMessageemiratesorstate}
            isErrorprovince={isErrorprovince}
            errorMessageemiratesorprovince={errorMessageemiratesorprovince}
            isErrorcountry={isErrorcountry}
            errorMessageemiratesorcountry={errorMessageemiratesorcountry}
            isErrortemporaryaddress={isErrortemporaryaddress}
            errorMessagetemporaryaddress={errorMessagetemporaryaddress}
            isErrorpermanentaddress={isErrorpermanentaddress}
            errorMessagepermanentaddress={errorMessagepermanentaddress}
            isErrorcompletepermanentaddress={isErrorcompletepermanentaddress}
            errorMessagecompletepermanentaddress={
              errorMessagecompletepermanentaddress
            }
            isErrornationality={isErrornationality}
            errorMessagenationality={errorMessagenationality}
            isErrordateofbirth={isErrordateofbirth}
            errorMessagedateofbirth={errorMessagedateofbirth}
            isErrorcoutnryofbirth={isErrorcoutnryofbirth}
            errorMessagecoutnryofbirth={errorMessagecoutnryofbirth}
          />
        )
      case 2:
        return (
          <CorpAddressDetails
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            //addCourse={this.addCourse}
            //coursesOptions={coursesOptions}
            // addLevel={this.addLevel}
            //levelOptions={levelOptions}
            level={level}
          />
        )
      case 3:
        return (
          <CorpPaymentDetails
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            //addCourse={this.addCourse}
            // coursesOptions={coursesOptions}
            //addLevel={this.addLevel}
            //levelOptions={levelOptions}
            level={level}
          />
        )
      case 3:
        return (
          <CorpTradelicenseDetails
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            //addCourse={this.addCourse}
            // coursesOptions={coursesOptions}
            //addLevel={this.addLevel}
            //levelOptions={levelOptions}
            level={level}
          />
        )
      case 5:
        return (
          <CorpSummary
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            firstname={firstname}
            lastname={lastname}
            email={email}
            phone={phone}
            //coursesChosenSummary={coursesChosenSummary}
            // chosenLevel={chosenLevel}
            submitData={this.submitData}
          />
        )
      default:
        return null
    }
  }
}

export default Corporate
