import React, { Fragment, useContext, useEffect } from 'react'
//import PropTypes from 'prop-types'
//import { verifyUser } from '../../actions/verify-user'
//import UserList from '../../components/user-list'
//import { AppContext } from '../../App'
import './dashboard.css'

//import './bootstrap/dist/css/bootstrap.min.css'
//import '../bootstrap/dist/css/bootstrap.css'

//import '../../node_modules//bootstrap/dist/css/bootstrap-theme.css'
//import './Form'
import './dashboard.css'
import { Component } from 'react'
//import Form from '../Form'
//import './Individual'
//import '../node_modules/bootstrap/dist/css/bootstrap.min.css'

class dashboard extends Component {
  handleClick1 () {
    this.props.history.push('/individual')
  }
  handleClick2 () {
    this.props.history.push('/corporate')
  }

  onSubmit = e => {
    e.preventDefault()
    console.log(this.state)
  }

  render () {
    return (
      <div className='card col-12 col-lg-4 login-card mt-2 hv-center'>
        <form className='App'>
          <button
            className='btn btn-primary '
            onClick={() => this.handleClick1()}
            type='submit'
            name='Individual'
            value='Individual'
          >
            Individual
          </button>
          &nbsp; &nbsp;
          <button
            className='btn btn-primary'
            onClick={() => this.handleClick2()}
            type='submit'
            name='Corporate'
            value='corporate'
          >
            Corporate
          </button>
        </form>
      </div>
    )
  }
}

export default dashboard
